/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.edu.ifam.modelo;

import br.edu.ifam.jdbc.ConnectionFactory;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Calendar;

/**
 *
 * @author Jucibs
 */
public class ContaReceberDao {
    private Connection connection;

    public ContaReceberDao() {
        connection = new ConnectionFactory().getConnection();
    }

    public void adiciona(ContaReceber contaRec) {
        String sql = "insert into contasreceber"
                + "(noConta,codigo_contato,datacompra,datavencimento,"
                + "valorcompra,percjurosdia) "
                + "values(?,?,?,?,?,?)";
        try {
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setInt(1, contaRec.getNoConta());
            ps.setLong(2, contaRec.getContato().getId());
            Calendar compra = contaRec.getDataCompra();
            Date dataParaGravar = new Date(compra.getTimeInMillis());
            ps.setDate(3, dataParaGravar);
            Calendar venc = contaRec.getDataVencimento();
            dataParaGravar = new Date(venc.getTimeInMillis());
            ps.setDate(4, dataParaGravar);
            ps.setDouble(5, contaRec.getValorCompra());
            ps.setDouble(6, contaRec.getValorJuros());
            ps.executeUpdate();
            ps.close();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
}
